
import streamlit as st
import qrcode
from PIL import Image
import io

st.title("QR Code Generator")

# URL 입력
url = st.text_input("Enter your url")

if url != "":
    # QR 코드 생성
    qr = qrcode.QRCode(version = 1,
                       error_correction = qrcode.constants.ERROR_CORRECT_L, # L, M, Q, H
                       box_size = 10,
                       border = 4)
    qr.add_data(url)
    qr.make(fit = True)
    img = qr.make_image(fill_color = "black", back_color = "white")

    # PIL 이미지를 byte 데이터로 변환하기 위한 작업
    byte_arr = io.BytesIO()
    img.save(byte_arr, format = "PNG")
    byte_arr = byte_arr.getvalue()

    st.image(byte_arr, use_column_width = True)
